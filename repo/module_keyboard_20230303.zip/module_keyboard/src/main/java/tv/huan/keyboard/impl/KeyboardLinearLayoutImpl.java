package tv.huan.keyboard.impl;

import java.util.Arrays;
import java.util.List;

public interface KeyboardLinearLayoutImpl extends KeyboardImpl {

    String[][] mKeyFull = {{"A", "B", "C", "D", "E", "F"},
            {"G", "H", "I", "J", "K", "L"},
            {"M", "N", "O", "P", "Q", "R"},
            {"S", "T", "U", "V", "W", "X"},
            {"Y", "Z", "1", "2", "3", "4"},
            {"5", "6", "7", "8", "9", "0"}};

    String[][] mKeyT9 = {{"0  1", "2\nA B C", "3\nD E F"},
            {"4\nG H I", "5\nJ K L", "6\nM N O"},
            {"7\nP Q R S", "8\nT U V", "9\nW X Y Z"}};
    List<String> mKeyT9Left = Arrays.asList(
            "1",
            "A", "B",
            "D", "E",
            "G", "H",
            "J", "K",
            "M", "N",
            "P", "Q", "S",
            "T", "U",
            "W", "X", "Z");
    List<String> mKeyT9Right = Arrays.asList(
            "0",
            "C", "B",
            "F", "E",
            "I", "H",
            "L", "K",
            "O", "N",
            "R", "Q", "S",
            "V", "U",
            "Y", "X", "Z");
    List<String> mKeyT9Up = Arrays.asList(
            "0", "1",
            "B", "A", "C",
            "E", "D", "F",
            "H", "G", "I",
            "K", "J", "L",
            "N", "M", "O",
            "Q", "P", "R",
            "U", "T", "V",
            "X", "W", "Y");
    List<String> mKeyT9Down = Arrays.asList(
            "0", "1",
            "2", "A", "C",
            "3", "D", "F",
            "4", "G", "I",
            "5", "J", "L",
            "6", "M", "O",
            "S", "P", "R",
            "8", "T", "V",
            "Z", "W", "Y");
    List<String> mKeyLast = Arrays.asList(
//            "5",
//            "6",
//            "7",
//            "8",
//            "9",
//            "0",
            "S", "P", "R",
            "8", "T", "V",
            "Z", "W", "Y");
}
