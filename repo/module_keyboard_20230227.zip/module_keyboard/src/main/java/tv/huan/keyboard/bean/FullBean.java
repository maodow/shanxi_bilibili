package tv.huan.keyboard.bean;

public final class FullBean extends BaseBean {
    @Override
    public boolean isT9() {
        return false;
    }

    @Override
    public boolean isMenu() {
        return false;
    }
}
