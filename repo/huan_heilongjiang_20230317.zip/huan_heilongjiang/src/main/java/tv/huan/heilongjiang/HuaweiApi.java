

package tv.huan.heilongjiang;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

public final class HuaweiApi {

    public static String getEpgServer(Context context) {
        String s = getValue(context, "epg_server", "");
        if (null != s && s.length() > 0) {
            return s + BuildConfig.EPG_PATH;
        } else {
            return "";
        }
    }

    public static String getUserToken(Context context) {
        return getValue(context, "user_token", "");
    }

    public static String getUserName(Context context) {
        return getValue(context, "username", "");
    }

    private static String getValue(Context context, String key, String defaults) {

        String v = null;
        try {
            // content://stbconfig/authentication
            Uri uri = Uri.parse("content://stbconfig/authentication/" + key);

            Cursor cursor = context.getContentResolver().query(uri, null, "name = ?", new String[]{key}, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex("value");
                v = cursor.getString(index);
            }
            if (null != cursor) {
                cursor.close();
            }
            if (null == v || v.length() <= 0) {
                v = defaults;
            }
        } catch (Exception e) {
            v = defaults;
        }
        Log.e("HuaweiApi", "getValue => key = " + key + ", value = " + v);
        return v;
    }
}
