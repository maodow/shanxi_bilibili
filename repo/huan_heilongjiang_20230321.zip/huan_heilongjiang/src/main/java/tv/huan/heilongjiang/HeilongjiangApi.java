package tv.huan.heilongjiang;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import com.istv.ystframework.callback.ResultCallBack;
import com.istv.ystframework.client.OrderClient;

import org.json.JSONObject;

public final class HeilongjiangApi {

    public static boolean init(Context context) {
        return init(context, BuildConfig.APP_ID, BuildConfig.APP_KEY);
    }

    public static boolean init(Context context, String appId, String appKey) {
        try {
            logE("HeilongjiangApi", "init =>");
            OrderClient.init(context, appId, appKey, new ResultCallBack() {
                @Override
                public void onResult(String s) {
                    logE("HeilongjiangApi", "init => s = " + s);
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getUserId(Context context) {
        return getUserId(context, BuildConfig.APP_ID, BuildConfig.APP_KEY);
    }

    public static String getUserId(Context context,
                                   String appid,
                                   String appkey) {
        try {
            String userId = OrderClient.getUserId(context, appid, appkey);
            if (null == userId || userId.length() <= 0)
                throw new Exception("userId error: " + userId);
            return userId;
        } catch (Exception e) {
            return "";
        }
    }

    public static String getPhoneNo(Context context) {
        try {
            return OrderClient.getPhoneNo(context);
        } catch (Exception e) {
            return "";
        }
    }

    public static void checkVip(Context context,
                                OnStatusChangeListener l) {
        checkVip(context, BuildConfig.APP_ID, BuildConfig.APP_KEY, BuildConfig.PRODUCT_ID, l);
    }

    /**
     * 判断用户是否购买过内容对应的产品包，未订购的场合返回该内容所关联的产品包列表。
     *
     * @param context
     * @param appid
     * @param appkey
     * @param productId
     */
    public static void checkVip(Context context,
                                String appid,
                                String appkey,
                                String productId,
                                OnStatusChangeListener l) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String userId = getUserId(context, appid, appkey);
                logE("HeilongjiangApi", "checkVip => appid = " + appid);
                logE("HeilongjiangApi", "checkVip => appkey = " + appkey);
                logE("HeilongjiangApi", "checkVip => productId = " + productId);
                logE("HeilongjiangApi", "checkVip => userId = " + userId);

                OrderClient.authOrize_V3(context, appid, appkey, userId, "", productId, "1", new ResultCallBack() {
                    @Override
                    public void onResult(String s) {
                        logE("HeilongjiangApi", "checkVip => s = " + s);
                        if (null != l) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        JSONObject object = new JSONObject(s);
                                        String result = object.optString("result", null);
                                        if (null == result || !"ORD-000".equals(result))
                                            throw new Exception("fail");
                                        l.onPass();
                                    } catch (Exception e) {
                                        l.onFail();
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }).start();
    }

    public static void jumpVip(Context context,OnStatusChangeListener l) {
        jumpVip(context, BuildConfig.APP_ID, BuildConfig.APP_KEY, BuildConfig.PRODUCT_ID, l);
    }

    /**
     * 跳转SDK中原生支付页面，支付结果在callback里返回（建议支付完成后，最好重新走鉴权逻辑，看是否订购成功）
     *
     * @param context
     * @param appid
     * @param appkey
     * @param productId
     */
    public static void jumpVip(Context context,
                               String appid,
                               String appkey,
                               String productId,
                               OnStatusChangeListener l) {
        String userId = getUserId(context, appid, appkey);
        logE("HeilongjiangApi", "jumpVip => appid = " + appid);
        logE("HeilongjiangApi", "jumpVip => appkey = " + appkey);
        logE("HeilongjiangApi", "jumpVip => productId = " + productId);
        logE("HeilongjiangApi", "jumpVip => userId = " + userId);

        OrderClient.goOrder_V3(context, appid, appkey, productId, "1", "test-content", userId, new ResultCallBack() {
            @Override
            public void onResult(String s) {
                // {"message":"业务受理确认","result":"ORD-000"}
                logE("HeilongjiangApi", "jumpVip => s = " + s);
                if (null != l) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONObject object = new JSONObject(s);
                                String result = object.optString("result", null);
                                if (null == result || !"ORD-000".equals(result))
                                    throw new Exception("fail");
                                l.onPass();
                            } catch (Exception e) {
                                l.onFail();
                            }
                        }
                    });
                }
            }
        });
    }

    public static String getEpgServer(Context context) {
        String s = getValue(context, "epg_server", "");
        if (null != s && s.length() > 0) {
            return s + BuildConfig.EPG_PATH;
        } else {
            return "";
        }
    }

    public static String getUserToken(Context context) {
        return getValue(context, "user_token", "");
    }

    public static String getUserName(Context context) {
        return getValue(context, "username", "");
    }

    private static String getValue(Context context, String key, String defaults) {

        String v = null;
        try {
            // content://stbconfig/authentication
            Uri uri = Uri.parse("content://stbconfig/authentication/" + key);

            Cursor cursor = context.getContentResolver().query(uri, null, "name = ?", new String[]{key}, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex("value");
                v = cursor.getString(index);
            }
            if (null != cursor) {
                cursor.close();
            }
            if (null == v || v.length() <= 0) {
                v = defaults;
            }
        } catch (Exception e) {
            v = defaults;
        }
        logE("HuaweiApi", "getValue => key = " + key + ", value = " + v);
        return v;
    }


    /*****************************/

    private static boolean mEnable = false;

    public static void setLogger(boolean v) {
        mEnable = v;
    }

    private static void logE(@NonNull String tag, @NonNull String s) {
        if (!mEnable)
            return;
        if (null == s || s.length() <= 0)
            return;
        Log.e(tag, s);
    }
}
