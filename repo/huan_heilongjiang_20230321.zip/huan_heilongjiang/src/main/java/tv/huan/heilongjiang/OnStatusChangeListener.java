package tv.huan.heilongjiang;

import androidx.annotation.Keep;

@Keep
public interface OnStatusChangeListener {

    void onPass();

    void onFail();
}
