package tv.huan.heilongjiang;

import androidx.annotation.Keep;

@Keep
public interface OnCheckVipChangeListener {

    void onPass();

    void onFail();
}
