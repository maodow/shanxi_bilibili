package com.project.adtest.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;


import com.project.adtest.R;
import com.project.adtest.TestActivity;

import tv.scene.ad.opensdk.AdSlot;
import tv.scene.ad.opensdk.INormAd;
import tv.scene.ad.opensdk.SceneAdSDK;
import tv.scene.ad.opensdk.basecallback.AbsAdListener;
import tv.scene.ad.opensdk.basecallback.INormAdFactory;


public class SplashActivity extends Activity {
    public static final String SPLASH = "test-kaiping";
    FrameLayout ly;
    INormAd iNormAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ly = findViewById(R.id.container);
        getAd();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void getAd() {

        AdSlot slot = new AdSlot.Builder()
                .setCodeId(SPLASH)
                .setDisplayCountDown(true)
                .setPlayView(AdSlot.USE_SURFACEVIEW)
                .build();

        INormAdFactory imp = SceneAdSDK.getAdManager().createAdFactory(this);
        imp.loadAd(slot, new AbsAdListener() {
            @Override
            public void onError(int code, String message) {
                Log.i("gxh", "onError: " + message);
            }

            @Override
            public void onLoadAd(INormAd normAd) {
                iNormAd = normAd;
                normAd.startPlay(ly);
            }


            @Override
            public void onComplete(View v) {
                finish();
            }

            @Override
            public void onSkip() {
                finish();
            }

            @Override
            public void onUpdate(int countDownTime, int totalTime, int canExitTime) {
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(iNormAd != null){
            iNormAd.release();
        }
    }
}