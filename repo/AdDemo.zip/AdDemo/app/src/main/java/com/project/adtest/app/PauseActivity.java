package com.project.adtest.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.project.adtest.R;

import tv.scene.ad.opensdk.AdSlot;
import tv.scene.ad.opensdk.INormAd;
import tv.scene.ad.opensdk.SceneAdSDK;
import tv.scene.ad.opensdk.basecallback.AbsAdListener;
import tv.scene.ad.opensdk.basecallback.INormAdFactory;

/**
 * 暂停
 */
public class PauseActivity extends Activity {

    public static final String PAUSE = "test-zanting";

    FrameLayout ly;

    INormAd mPauseNormAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pause);
        ly = findViewById(R.id.container);
        getAd();

    }

    private void getAd() {
        INormAdFactory imp = SceneAdSDK.getAdManager().createAdFactory(this);
        AdSlot slot = new AdSlot.Builder()
                .setCodeId(PAUSE)
                .setDisplayCountDown(false)
                .build();

        imp.loadAd(slot, new AbsAdListener() {
            @Override
            public void onError(int i, String s) {
                Toast.makeText(getApplicationContext(), i + " " + s, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onLoadAd(INormAd iNormAd) {
                iNormAd.startPlay(ly);
                mPauseNormAd = iNormAd;
            }
        });
    }
}
