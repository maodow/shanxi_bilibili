package com.project.adtest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.project.adtest.app.CornerActivity;
import com.project.adtest.app.PauseActivity;
import com.project.adtest.app.ScreensaverActivity;
import com.project.adtest.app.SplashActivity;


public class TestActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }

    public void toSplash(View view) {
        startActivity(new Intent(this, SplashActivity.class));
    }


    public void toPause(View view) {
        startActivity(new Intent(this, PauseActivity.class));
    }

    public void toCorner(View view) {
        startActivity(new Intent(this, CornerActivity.class));
    }

    public void toScreensaver(View view) {
        startActivity(new Intent(this, ScreensaverActivity.class));
    }
}
