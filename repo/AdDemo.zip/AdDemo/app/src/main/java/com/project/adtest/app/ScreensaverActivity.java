package com.project.adtest.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

import com.project.adtest.R;

import tv.scene.ad.opensdk.AdSlot;
import tv.scene.ad.opensdk.INormAd;
import tv.scene.ad.opensdk.SceneAdSDK;
import tv.scene.ad.opensdk.basecallback.AbsAdListener;
import tv.scene.ad.opensdk.basecallback.INormAdFactory;

/**
 * 屏保
 * @author gxh
 * @time 2023/1/12 13:54
 */
public class ScreensaverActivity extends Activity {
    private static final String SCREENSAVER = "test-pingbao";
    FrameLayout contentView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pingbao);

        contentView = findViewById(R.id.adContainer);

        AdSlot slot = new AdSlot.Builder()
                .setCodeId(SCREENSAVER)
                .setDisplayCountDown(false)
                .build();

        INormAdFactory imp = SceneAdSDK.getAdManager ().createAdFactory (this);
        imp.loadAd(slot, new AbsAdListener() {
            @Override
            public void onError(int code, String message) {

            }

            @Override
            public void onLoadAd(INormAd normAd) {
                normAd.startPlay(contentView);
            }

            @Override
            public void onComplete(View view) {
                super.onComplete(view);
            }
        });
    }
}
