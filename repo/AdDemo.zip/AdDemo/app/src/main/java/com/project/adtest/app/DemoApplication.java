package com.project.adtest.app;


import androidx.multidex.MultiDexApplication;

import tv.scene.ad.opensdk.SceneAdConfig;
import tv.scene.ad.opensdk.SceneAdSDK;


/**
 * Created by Thinkpad on 2018/1/30.
 */

public class DemoApplication extends MultiDexApplication {


    /**
     * 请将APP_KEY替换成自己的
     */
    static final String APPKEY = "7dc15107ec1341ae80bf5f49fee16af2";
    
    @Override
    public void onCreate () {
        super.onCreate ();
        initAdConfig ();
    }
    
    /**
     * 初始化广告sdk, 在application中的oncreate执行
     */
    private void initAdConfig () {
        SceneAdConfig config = new SceneAdConfig.Builder ()
                //appkey到后台申请，每个应用保证唯一性
                .setAppKey (APPKEY)
                //应用名称，对接应用添加
                .setAppName ("广告SDKv4.3.1.1 sample")
                //测试阶段打开，可以通过日志排查问题，上线时去除该调用
                .setOpenLog (true)
                .setDebugUrl(true)
                //厂商设置
                .setManufacture ("厂商渠道")
                //机型设置
                .setDeviceModel ("机型")
                .setRequestTimeOutSeconds(10)
                .builder ();
        SceneAdSDK.init (this, config);
    }
    
}
