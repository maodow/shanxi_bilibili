package com.project.adtest.app;//package com.project.adtest;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.project.adtest.R;

import tv.scene.ad.opensdk.AdSlot;
import tv.scene.ad.opensdk.SceneAdSDK;
import tv.scene.ad.opensdk.basecallback.TVPlayCallback;
import tv.scene.ad.opensdk.INormAd;
import tv.scene.ad.opensdk.basecallback.AbsAdListener;
import tv.scene.ad.opensdk.basecallback.INormAdFactory;

/**
 * banner or  角标
 */
public class CornerActivity extends Activity {
    private static final String JIAOBIAO = "test-banner";

    RelativeLayout root;
    FrameLayout ly;
    TextView currentPositionText;

    protected INormAd mIaiAd;
    private TVPlayCallback mangoTVPlayCallback;
    private INormAdFactory imp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView (R.layout.activity_jiaobiao);

        ly = findViewById(R.id.container);
        currentPositionText = findViewById(R.id.currentPositionText);
        root = findViewById(R.id.root);

        getAd ();
    }

    private final int playerWindowDefault = 0;
    private final int playerWindowHalf = 1;
    private int playerWindowState = playerWindowDefault;
    public void smallScreen(View view) {
        int scale = 0;
        switch (playerWindowState){
            case playerWindowDefault:
                scale = 2;
                break;
            case playerWindowHalf:
                scale = 1;
                break;
        }
        playerWindowState++;
        if(playerWindowState > playerWindowHalf){
            playerWindowState = playerWindowDefault;
        }
        ViewGroup.LayoutParams layoutParams = root.getLayoutParams();
        layoutParams.width = getScreenWidth() / scale;
        layoutParams.height = getScreenHeight() / scale;
        root.setLayoutParams(layoutParams);

        root.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (mIaiAd != null) {
                    mIaiAd.onSizeChanged(1,1);
                }
                root.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }

    private void getAd () {
        mangoTVPlayCallback = new TVPlayCallback() {
            int i = 0;
            @Override
            public int getPlayTime () {
                if (i > 145 * 1000) {
                    i = 25 * 1000;
                }
                int value = i += 500;
                currentPositionText.setText("模拟视频播放进度 " + (value / 1000) +"s");
                return value;
            }
        };

        AdSlot slot = new AdSlot.Builder ()
                .setCodeId (JIAOBIAO)
                .setMediaId ("12087666")
                .setDisplayCountDown (false)
                .build ();

        imp = SceneAdSDK.getAdManager ().createAdFactory (this);
        imp.loadPoint(ly, slot, mangoTVPlayCallback, new AbsAdListener() {
            @Override
            public void onError(int code, String message) {
                Log.i("aaa", "onError: ");
            }

            @Override
            public void onTimeout() {

            }
            @Override
            public void onStart (View view) {
            }

            @Override
            public void onComplete (View view) {
            }

            @Override
            public void onSkip() {

            }

            @Override
            public void onAdClicked (View view) {
            }

            @Override
            public void onLoadAd(INormAd normAd) {
                mIaiAd = normAd;
            }

        });
    }

    @Override
    protected void onDestroy () {
        super.onDestroy ();
        imp.releasePoint ();
    }

    /**
     * 获得屏幕宽度
     *
     * @return
     */
    public int getScreenWidth() {
        WindowManager wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }

    /**
     * 获得屏幕高度
     *
     * @return
     */
    public int getScreenHeight() {
        WindowManager wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.heightPixels;
    }
}
