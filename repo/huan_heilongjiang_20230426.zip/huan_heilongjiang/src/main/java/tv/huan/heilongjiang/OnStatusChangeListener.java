package tv.huan.heilongjiang;

import androidx.annotation.Keep;

@Keep
interface OnStatusChangeListener {

    void onPass();

    void onFail();
}
