package com.huan.keyboard;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Space;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.huan.keyboard.impl.KeyboardLinearLayoutImpl;

import tv.huan.base.R;

/**
 * 搜索键盘
 */
@Keep
public class KeyboardLinearLayout extends LinearLayout implements KeyboardLinearLayoutImpl {

    @DrawableRes
    private int mBackgroundFull = 0;
    @DrawableRes
    private int mBackgroundT9 = 0;
    @DrawableRes
    private int mBackgroundMenu = 0;
    private int mWeightSum = 8;
    private int mWeightSpace = 1;
    private int mMarginT9 = 0;
    private int mMarginFull = 0;
    private int mMarginMenu = 0;
    private String mFocusText;

    public KeyboardLinearLayout(@NonNull Context context) {
        super(context);
        init(context, null);
    }

    public KeyboardLinearLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public KeyboardLinearLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        initKeysT9();
        initKeysFull();
        initKeysMenu();
    }

    private final void init(Context context, AttributeSet attrs) {
        TypedArray attributes = null;
        try {
            attributes = context.obtainStyledAttributes(attrs, R.styleable.KeyboardLinearLayout);
            mFocusText = attributes.getString(R.styleable.KeyboardLinearLayout_kll_focus_text);
            mBackgroundMenu = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_menu, 0);
            mBackgroundFull = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_full, 0);
            mBackgroundT9 = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_item_t9, 0);
            mWeightSum = attributes.getInt(R.styleable.KeyboardLinearLayout_kll_weight_sum, 8);
            mWeightSpace = attributes.getInt(R.styleable.KeyboardLinearLayout_kll_weight_space, 1);
            mMarginT9 = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_t9, 0);
            mMarginFull = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_full, 0);
            mMarginMenu = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_menu, 0);
        } catch (Exception e) {
        }
        if (null != attributes) {
            attributes.recycle();
        }
        setAnimation(null);
        setAnimationCacheEnabled(false);
        setFocusableInTouchMode(false);
        setOrientation(LinearLayout.VERTICAL);
        setWeightSum(mWeightSum);
    }

    private final void initKeysT9() {
        // 竖
        for (int i = 0; i < 3; i++) {
            LinearLayout vtLayout = new LinearLayout(getContext());
            vtLayout.setPadding(0, 0, 0, 0);
            vtLayout.setVisibility(View.GONE);
            vtLayout.setOrientation(LinearLayout.HORIZONTAL);
            vtLayout.setFocusable(false);
            vtLayout.setId(R.id.keyboard_id_t9);
            vtLayout.setWeightSum(3);
            LinearLayout.LayoutParams vtParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 2);
            if (i == 0) {
                vtParams.topMargin = 0;
                vtParams.bottomMargin = mMarginT9;
            } else if (i == 2) {
                vtParams.topMargin = mMarginT9;
                vtParams.bottomMargin = 0;
            } else {
                vtParams.bottomMargin = mMarginT9;
                vtParams.topMargin = mMarginT9;
            }
            vtLayout.setLayoutParams(vtParams);
            addView(vtLayout);
            // 横
            for (int j = 0; j < 3; j++) {
                // 1
                View inflate = LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_t9, null);
                LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                if (j == 0) {
                    keyParams.rightMargin = mMarginT9;
                } else if (j == 5) {
                    keyParams.leftMargin = mMarginT9;
                } else {
                    keyParams.rightMargin = mMarginT9;
                    keyParams.leftMargin = mMarginT9;
                }
                keyParams.topMargin = 0;
                keyParams.bottomMargin = 0;
                inflate.setLayoutParams(keyParams);
                vtLayout.addView(inflate);

                // 2
                for (int n = 0; n < 5; n++) {
                    TextView textView = null;
                    if (n == 0) {
                        textView = inflate.findViewById(R.id.keyboard_t9_center);
                    } else if (n == 1) {
                        textView = inflate.findViewById(R.id.keyboard_t9_left);
                    } else if (n == 2) {
                        textView = inflate.findViewById(R.id.keyboard_t9_top);
                    } else if (n == 3) {
                        textView = inflate.findViewById(R.id.keyboard_t9_right);
                    } else if (n == 4) {
                        textView = inflate.findViewById(R.id.keyboard_t9_bottom);
                    }

                    if (null == textView)
                        continue;
                    textView.setBackgroundResource(mBackgroundT9);
                    textView.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String s;
                            try {
                                s = ((TextView) v).getText().toString();
                            } catch (Exception e) {
                                s = null;
                            }
                            append(s);
                        }
                    });
                    textView.setOnKeyListener(new OnKeyListener() {
                        @Override
                        public boolean onKey(View v, int keyCode, KeyEvent event) {
                            // left
                            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {
                                CharSequence sequence = ((TextView) v).getText();
                                if (mKeyT9Left.contains(sequence)) {
                                    hideFloatT9(inflate);
                                    return true;
                                }
                            }
                            // right
                            else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {


                            }
                            // up
                            else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {


                            }
                            // down
                            else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {


                            }
                            return false;
                        }
                    });

                    String trim = mKeyT9[i][j].replace("\n", "").trim();
                    int length = trim.length();
                    if (n + 1 > length)
                        continue;
                    char c = trim.charAt(n);
                    textView.setText(String.valueOf(c));
                }
                // 3
                KeyView keyView = inflate.findViewById(R.id.keyboard_t9_preview);
                keyView.setId(R.id.keyboard_id_t9_float);
                keyView.setFocusable(true);
                keyView.setBackgroundResource(mBackgroundT9);
                keyView.setText(mKeyT9[i][j]);
                keyView.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.e("KeyboardView", "onClick");
                        showFloatT9(v);
                    }
                });
                if (i != 2)
                    continue;
                keyView.setOnKeyListener(new OnKeyListener() {
                    @Override
                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
                            RadioButton radioT9 = findViewById(R.id.keyboard_id_menu_t9);
                            if (radioT9.isChecked()) {
                                radioT9.requestFocus();
                                return true;
                            } else {
                                RadioButton radioFull = findViewById(R.id.keyboard_id_menu_full);
                                if (radioFull.isChecked()) {
                                    radioFull.requestFocus();
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                });
            }
        }
    }

    private final void initKeysFull() {
        Log.e("KeyboardLinearLayout", "initKeysFull => mMarginFull = " + mMarginFull);

        View focusView = null;

        // 竖
        for (int i = 0; i < 6; i++) {
            LinearLayout vtLayout = new LinearLayout(getContext());
            vtLayout.setPadding(0, 0, 0, 0);
            vtLayout.setVisibility(View.VISIBLE);
            vtLayout.setOrientation(LinearLayout.HORIZONTAL);
            vtLayout.setFocusable(false);
            vtLayout.setId(R.id.keyboard_id_full);
            vtLayout.setWeightSum(6);
            LinearLayout.LayoutParams vtParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            if (i == 0) {
                vtParams.topMargin = 0;
                vtParams.bottomMargin = mMarginFull;
            } else if (i == 5) {
                vtParams.topMargin = mMarginFull;
                vtParams.bottomMargin = 0;
            } else {
                vtParams.bottomMargin = mMarginFull;
                vtParams.topMargin = mMarginFull;
            }
            vtLayout.setLayoutParams(vtParams);
            addView(vtLayout);
            // 横
            for (int j = 0; j < 6; j++) {
                // 1
                KeyView keyView = (KeyView) LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_full, null);
                keyView.setId(R.id.keyboard_id_full_key);
                LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                if (j == 0) {
                    keyParams.rightMargin = mMarginFull;
                } else if (j == 5) {
                    keyParams.leftMargin = mMarginFull;
                } else {
                    keyParams.rightMargin = mMarginFull;
                    keyParams.leftMargin = mMarginFull;
                }
                keyParams.topMargin = 0;
                keyParams.bottomMargin = 0;
                keyView.setLayoutParams(keyParams);
                vtLayout.addView(keyView);
                // 2
                keyView.setFocusable(true);
                keyView.setBackgroundResource(mBackgroundFull);
                keyView.setText(mKeyFull[i][j]);
                if (mKeyFull[i][j].equals(mFocusText)) {
                    focusView = keyView;
                }
                keyView.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String s;
                        try {
                            s = ((TextView) v).getText().toString();
                        } catch (Exception e) {
                            s = null;
                        }
                        append(s);
                    }
                });
                if (i != 5)
                    continue;
                keyView.setOnKeyListener(new OnKeyListener() {
                    @Override
                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
                            RadioButton radioT9 = findViewById(R.id.keyboard_id_menu_t9);
                            if (radioT9.isChecked()) {
                                radioT9.requestFocus();
                                return true;
                            } else {
                                RadioButton radioFull = findViewById(R.id.keyboard_id_menu_full);
                                if (radioFull.isChecked()) {
                                    radioFull.requestFocus();
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                });
            }
        }

        if (null != focusView) {
            focusView.requestFocus();
        }
    }

    private final void initKeysMenu() {
        // 间距
        Space space = new Space(getContext());
        space.setId(R.id.keyboard_id_space);
        space.setVisibility(View.VISIBLE);
        space.setFocusable(false);
        LinearLayout.LayoutParams spParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, mWeightSpace);
        space.setLayoutParams(spParams);
        addView(space);
        // 菜单
        RadioGroup hzLayout = new RadioGroup(getContext());
        hzLayout.setId(R.id.keyboard_id_menu);
        hzLayout.setVisibility(View.VISIBLE);
        hzLayout.setOrientation(LinearLayout.HORIZONTAL);
        hzLayout.setFocusable(false);
        hzLayout.setWeightSum(2);
        LinearLayout.LayoutParams vtParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        hzLayout.setLayoutParams(vtParams);
        addView(hzLayout);
        for (int i = 0; i < 2; i++) {
            KeyButton keyButton = new KeyButton(getContext());
            keyButton.setId(i == 0 ? R.id.keyboard_id_menu_full : R.id.keyboard_id_menu_t9);
            keyButton.setFocusable(true);
            keyButton.setChecked(i == 0);
            keyButton.setBackgroundResource(mBackgroundMenu);
            keyButton.setText(i == 0 ? R.string.keyboard_full : R.string.keyboard_t9);
            keyButton.setOnFocusChangeListener(new OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    // t9
                    if (hasFocus && R.id.keyboard_id_menu_t9 == v.getId()) {
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_t9)).setChecked(true);
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_full)).setChecked(false);
                        showT9();
                    }
                    // full
                    else if (hasFocus && R.id.keyboard_id_menu_full == v.getId()) {
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_t9)).setChecked(false);
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_full)).setChecked(true);
                        showFull();
                    }
                }
            });
            LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1);
            if (i == 0) {
                keyParams.leftMargin = 0;
                keyParams.rightMargin = mMarginMenu;
            } else {
                keyParams.leftMargin = mMarginMenu;
                keyParams.rightMargin = 0;
            }
            keyButton.setLayoutParams(keyParams);
            hzLayout.addView(keyButton);
        }
    }

    private final void showT9() {
        int childCount = getChildCount();
        if (childCount <= 0)
            return;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (null == childAt)
                continue;
            int id = childAt.getId();
            childAt.setVisibility(id != R.id.keyboard_id_full ? View.VISIBLE : View.GONE);
        }
    }

    private final void showFull() {
        int childCount = getChildCount();
        if (childCount <= 0)
            return;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (null == childAt)
                continue;
            int id = childAt.getId();
            childAt.setVisibility(id != R.id.keyboard_id_t9 ? View.VISIBLE : View.GONE);
        }
    }

    private void hideFloatT9(View viewGroup) {
        viewGroup.findViewById(R.id.keyboard_t9_keys).setVisibility(View.GONE);
        viewGroup.findViewById(R.id.keyboard_t9_preview).setVisibility(View.VISIBLE);
        viewGroup.findViewById(R.id.keyboard_t9_preview).requestFocus();
//        ViewGroup viewGroup = (ViewGroup) collect.getParent();
//        Log.e("UYUYU", "hideFloatT9 => viewGroup = " + viewGroup);
//        ViewGroup priview = viewGroup.findViewById(R.id.keyboard_t9_preview);
//        Log.e("UYUYU", "hideFloatT9 => priview = " + priview);
//        priview.requestFocus();
    }

    private void showFloatT9(View view) {
        String s;
        try {
            s = ((TextView) view).getText().toString();
        } catch (Exception e) {
            s = null;
        }
        if (null == s || s.length() <= 0)
            return;

        String trim = s.replace("\n", "").trim();
        char[] chars = trim.toCharArray();
        if (null == chars)
            return;

        int length = chars.length;
        if (length != 2 && length != 4 && length != 5)
            return;

        ViewGroup viewGroup = (ViewGroup) view.getParent();
        viewGroup.findViewById(R.id.keyboard_t9_keys).setVisibility(View.VISIBLE);
        // 01
        if (length == 2) {
            viewGroup.findViewById(R.id.keyboard_t9_left).requestFocus();
        }
        // 7PQRS,9WXYZ
        else if (length == 5) {
            viewGroup.findViewById(R.id.keyboard_t9_center).requestFocus();
        }
        // normal
        else {
            viewGroup.findViewById(R.id.keyboard_t9_center).requestFocus();
        }
    }
}
