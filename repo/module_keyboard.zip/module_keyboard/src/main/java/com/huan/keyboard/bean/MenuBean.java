package com.huan.keyboard.bean;

public final class MenuBean extends BaseBean {
    @Override
    public boolean isT9() {
        return false;
    }

    @Override
    public boolean isMenu() {
        return true;
    }
}
