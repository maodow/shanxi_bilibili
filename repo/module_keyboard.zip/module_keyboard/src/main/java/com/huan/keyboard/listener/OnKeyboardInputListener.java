package com.huan.keyboard.listener;

import androidx.annotation.Keep;

@Keep
public interface OnKeyboardInputListener {

    void onInput(String result);
}
