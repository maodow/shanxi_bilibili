package com.huan.keyboard;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;

import com.huan.keyboard.bean.BaseBean;
import com.huan.keyboard.impl.KeyboardGridViewImpl;
import com.huan.keyboard.impl.KeyboardLinearLayoutImpl;

import tv.huan.base.R;

/**
 * 搜索键盘
 */
@Keep
public class KeyboardGridView extends GridView implements KeyboardGridViewImpl {

    public KeyboardGridView(@NonNull Context context) {
        super(context);
        init(context, null);
    }

    public KeyboardGridView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, null);
    }

    public KeyboardGridView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, null);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setAdapter();
    }

    private final void init(Context context, AttributeSet attrs) {
        TypedArray attributes = null;
        try {
//            attributes = context.obtainStyledAttributes(attrs, R.styleable.KeyboardView);
        } catch (Exception e) {
        }
        if (null != attributes) {
            attributes.recycle();
        }
        setAnimation(null);
        setAnimationCacheEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setNestedScrollingEnabled(false);
        }
        setFocusableInTouchMode(false);
    }

    private void setAdapter() {
        GridLayoutManager manager = new GridLayoutManager(getContext(), 6) {
            @Override
            public boolean canScrollHorizontally() {
                return false;
            }

            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        manager.setOrientation(GridLayoutManager.VERTICAL);
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                try {
                    return getKey(position).getSpan();
                } catch (Exception e) {
                    throw e;
                }
            }
        });
        setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return getLength();
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {


                View view;
                if (null != convertView) {
                    view = convertView;
                } else {
                    BaseBean bean = getKey(position);
                    // menu
                    if (bean.isMenu()) {
                        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.module_keyboard_menu, null);
                    }
                    // t9
                    else if (bean.isT9()) {
                        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.module_keyboard_t9, null);
                    }
                    // full
                    else {
                        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.module_keyboard_full, null);
                    }
                }
                return view;
            }
        });
    }
}
