package com.huan.keyboard.impl;

import androidx.annotation.NonNull;

import com.huan.keyboard.listener.OnKeyboardInputListener;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public interface KeyboardLinearLayoutImpl {

    String[][] mKeyFull = {{"A", "B", "C", "D", "E", "F"},
            {"G", "H", "I", "J", "K", "L"},
            {"M", "N", "O", "P", "Q", "R"},
            {"S", "T", "U", "V", "W", "X"},
            {"Y", "Z", "1", "2", "3", "4"},
            {"5", "6", "7", "8", "9", "0"}};
    List<String> mKeyT9Down = Arrays.asList("5", "6", "7", "8", "9", "0");

    String[][] mKeyT9 = {{"0 1", "2\nABC", "3\nDEF"},
            {"4\nGHI", "5\nJKL", "6\nMNO"},
            {"7\nPQRS", "8\nTUV", "9\nWXYZ"}};
    List<String> mKeyT9Left = Arrays.asList("0", "A", "D", "G", "J", "M", "P", "T", "W");

    LinkedList<String> mInput = new LinkedList<>();
    OnKeyboardInputListener[] mListener = new OnKeyboardInputListener[1];

    default boolean hasListener() {
        try {
            return null != mListener && mListener.length == 1 && null != mListener[0];
        } catch (Exception e) {
            return false;
        }
    }

    default void setOnKeyboardInputListener(OnKeyboardInputListener l) {
        try {
            mListener[0] = null;
            mListener[0] = l;
        } catch (Exception e) {
        }
    }

    default String getInput() {
        int length = mInput.size();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            String s = mInput.get(i);
            builder.append(s);
        }
        return builder.toString();
    }

    default void delete() {
        mInput.removeLast();
        boolean hasListener = hasListener();
        if (hasListener) {
            String toString = getInput();
            mListener[0].onInput(toString);
        }
    }

    default void clear() {
        mInput.clear();
        boolean hasListener = hasListener();
        if (hasListener) {
            String toString = getInput();
            mListener[0].onInput(toString);
        }
    }

    default void append(@NonNull String v) {
        append(false, v);
    }

    default void append(@NonNull boolean clean, @NonNull String v) {
        if (clean) {
            mInput.clear();
        }
        mInput.addLast(v);
        boolean hasListener = hasListener();
        if (hasListener) {
            String toString = getInput();
            mListener[0].onInput(toString);
        }
    }

//    /**
//     * 默认请求焦点
//     */
//    public void requestKeyboard() {
//        RecyclerView recyclerView = findViewById(R.id.recycler_view);
//        if (null != recyclerView.getAdapter()) {
//            recyclerView.requestFocus();
////            recyclerView.setSelection(12);
//        }
//    }
}
