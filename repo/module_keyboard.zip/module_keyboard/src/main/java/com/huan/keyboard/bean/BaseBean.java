package com.huan.keyboard.bean;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.List;

public abstract class BaseBean implements Serializable {

    public abstract boolean isT9();

    public abstract boolean isMenu();

    public int getSpan() {
        return isT9() ? 2 : isMenu() ? 3 : 1;
    }

    @Nullable
    private List<String> values;
    @DrawableRes
    private int backgroundDrawableRes = 0;

    @Nullable
    public List<String> getValues() {
        return values;
    }

    public void setValues(@Nullable List<String> values) {
        this.values = values;
    }

    public int getBackgroundDrawableRes() {
        return backgroundDrawableRes;
    }

    public void setBackgroundDrawableRes(int backgroundDrawableRes) {
        this.backgroundDrawableRes = backgroundDrawableRes;
    }
}
