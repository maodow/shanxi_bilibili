package tv.huan.keyboard;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import tv.huan.keyboard.impl.KeyboardLinearLayoutImpl;
import tv.huan.keyboard.widget.FullView;

import java.util.List;

/**
 * 搜索键盘
 */
@Keep
public class KeyboardLinearLayout extends LinearLayout implements KeyboardLinearLayoutImpl {

    @DrawableRes
    private int mBackgroundFullItem = 0;
    @DrawableRes
    private int mBackgroundT9Item = 0;
    @DrawableRes
    private int mBackgroundT9Preview = 0;
    @DrawableRes
    private int mBackgroundT9Float = 0;
    @DrawableRes
    private int mBackgroundMenu = 0;
    private int mMarginT9 = 0;
    private int mMarginFull = 0;
    private int mMarginSpace = 0;
    private int mMarginMenu = 0;
    private String mFocusText;

    public KeyboardLinearLayout(@NonNull Context context) {
        super(context);
        init(context, null);
    }

    public KeyboardLinearLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public KeyboardLinearLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        initKeysT9();
        initKeysFull();
        initKeysMenu();
    }

    private final void init(Context context, AttributeSet attrs) {
        TypedArray attributes = null;
        try {
            attributes = context.obtainStyledAttributes(attrs, R.styleable.KeyboardLinearLayout);
            mFocusText = attributes.getString(R.styleable.KeyboardLinearLayout_kll_focus_text);
            mBackgroundMenu = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_menu, 0);
            mBackgroundFullItem = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_full, 0);
            mBackgroundT9Item = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_t9_item, 0);
            mBackgroundT9Preview = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_t9_preview, 0);
            mBackgroundT9Float = attributes.getResourceId(R.styleable.KeyboardLinearLayout_kll_background_t9_float, 0);
            mMarginT9 = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_t9, 0);
            mMarginFull = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_full, 0);
            mMarginMenu = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_menu, 0);
            mMarginSpace = attributes.getDimensionPixelOffset(R.styleable.KeyboardLinearLayout_kll_margin_space, 0);
        } catch (Exception e) {
        }
        if (null != attributes) {
            attributes.recycle();
        }
        setAnimation(null);
        setAnimationCacheEnabled(false);
        setFocusableInTouchMode(false);
        setOrientation(LinearLayout.VERTICAL);
    }

    private final void initKeysT9() {
        // 竖
        for (int i = 0; i < 3; i++) {
            ViewGroup rowLayout = (ViewGroup) LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_simple_t9_row, this, false);
            addView(rowLayout);
            if (null != rowLayout.getLayoutParams()) {
                if (i == 0) {
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = 0;
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = mMarginT9;
                } else if (i == 2) {
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = mMarginT9;
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = 0;
                } else {
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = mMarginT9;
                    ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = mMarginT9;
                }
                ((LayoutParams) rowLayout.getLayoutParams()).leftMargin = 0;
                ((LayoutParams) rowLayout.getLayoutParams()).rightMargin = 0;
            }
            // 横
            for (int m = 0; m < 3; m++) {
                // 1
                View t9Layout = LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_simple_t9, rowLayout, false);
                rowLayout.addView(t9Layout);
                // 2
                if (null != t9Layout.getLayoutParams()) {
                    if (m == 0) {
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).leftMargin = 0;
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).rightMargin = mMarginT9;
                    } else if (m == 1) {
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).leftMargin = mMarginT9;
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).rightMargin = mMarginT9;
                    } else {
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).leftMargin = mMarginT9;
                        ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).rightMargin = 0;
                    }
                    ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).topMargin = 0;
                    ((LinearLayout.LayoutParams) t9Layout.getLayoutParams()).bottomMargin = 0;
                }
                // 3
                TextView t9PreView = t9Layout.findViewById(R.id.module_keyboard_simple_t9_preview);
                t9PreView.setBackgroundResource(mBackgroundT9Preview);
                String s = mKeyT9[i][m];
                t9PreView.setText(s);
                t9PreView.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showFloatT9(s, (ViewGroup) v.getParent());
                    }
                });
                if (i == 2) {
                    t9PreView.setOnKeyListener(new OnKeyListener() {
                        @Override
                        public boolean onKey(View v, int keyCode, KeyEvent event) {
                            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
                                RadioButton radioT9 = findViewById(R.id.keyboard_id_menu_t9);
                                if (radioT9.isChecked()) {
                                    radioT9.requestFocus();
                                    return true;
                                } else {
                                    RadioButton radioFull = findViewById(R.id.keyboard_id_menu_full);
                                    if (radioFull.isChecked()) {
                                        radioFull.requestFocus();
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                    });
                }
                // 4
                ViewGroup t9FloatView = t9Layout.findViewById(R.id.module_keyboard_simple_t9_float);
                t9FloatView.setBackgroundResource(mBackgroundT9Float);
                // 5
                for (int n = 0; n < 5; n++) {
                    TextView keyView = null;
                    if (n == 0) {
                        keyView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_center);
                    } else if (n == 1) {
                        keyView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_left);
                    } else if (n == 2) {
                        keyView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_top);
                    } else if (n == 3) {
                        keyView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_right);
                    } else if (n == 4) {
                        keyView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_bottom);
                    }
                    View bottomLayout = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_bottom_layout);
                    bottomLayout.setVisibility((i == 0 && m >= 1) || (i == 2 && m == 1) || i == 1 ? View.GONE : View.VISIBLE);
                    View topLayout = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_top_layout);
                    topLayout.setVisibility(i == 0 && m == 0 ? View.GONE : View.VISIBLE);
                    View rightView = t9FloatView.findViewById(R.id.module_keyboard_simple_t9_float_right);
                    rightView.setVisibility(i == 0 && m == 0 ? View.GONE : View.VISIBLE);
                    if (null != keyView) {
                        // a
                        keyView.setBackgroundResource(mBackgroundT9Item);
                        String trim = mKeyT9[i][m].replace("\n", "").replace(" ", "").trim();
                        int length = trim.length();
                        if (n + 1 <= length) {
                            char c = trim.charAt(n);
                            keyView.setText(String.valueOf(c));
                        }
                        // b
                        keyView.setOnClickListener(new OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String s;
                                try {
                                    s = ((TextView) v).getText().toString();
                                } catch (Exception e) {
                                    s = null;
                                }
                                append(s);
                            }
                        });
                        keyView.setOnKeyListener(new OnKeyListener() {
                            @Override
                            public boolean onKey(View v, int keyCode, KeyEvent event) {
                                // left
                                if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {
                                    return dispatchEvent((TextView) v, mKeyT9Left, View.FOCUS_LEFT);
                                }
                                // right
                                else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_RIGHT) {
                                    return dispatchEvent((TextView) v, mKeyT9Right, View.FOCUS_RIGHT);
                                }
                                // up
                                else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP) {
                                    return dispatchEvent((TextView) v, mKeyT9Up, View.FOCUS_UP);
                                }
                                // down
                                else if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
                                    return dispatchEvent((TextView) v, mKeyT9Down, View.FOCUS_DOWN);
                                }
                                return false;
                            }
                        });
                    }
                }
            }
        }
    }

    private final void initKeysFull() {

        View focusView = null;

        // 竖
        for (int i = 0; i < 6; i++) {
            ViewGroup rowLayout = (ViewGroup) LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_simple_full_row, this, false);
            addView(rowLayout);
            if (i == 0) {
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = 0;
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = mMarginFull;
            } else if (i == 5) {
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = mMarginFull;
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = 0;
            } else {
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).bottomMargin = mMarginFull;
                ((LinearLayout.LayoutParams) rowLayout.getLayoutParams()).topMargin = mMarginFull;
            }
            // 横
            for (int j = 0; j < 6; j++) {
                // 1
                TextView keyView = (FullView) LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_simple_full, rowLayout, false);
                rowLayout.addView(keyView);
                // 2
                if (null != keyView.getLayoutParams()) {
                    if (j == 0) {
                        ((LinearLayout.LayoutParams) keyView.getLayoutParams()).rightMargin = mMarginFull;
                    } else if (j == 5) {
                        ((LinearLayout.LayoutParams) keyView.getLayoutParams()).leftMargin = mMarginFull;
                    } else {
                        ((LinearLayout.LayoutParams) keyView.getLayoutParams()).rightMargin = mMarginFull;
                        ((LinearLayout.LayoutParams) keyView.getLayoutParams()).leftMargin = mMarginFull;
                    }
                    ((LinearLayout.LayoutParams) keyView.getLayoutParams()).topMargin = 0;
                    ((LinearLayout.LayoutParams) keyView.getLayoutParams()).bottomMargin = 0;
                }
                // 3
                keyView.setFocusable(true);
                keyView.setBackgroundResource(mBackgroundFullItem);
                keyView.setText(mKeyFull[i][j]);
                if (mKeyFull[i][j].equals(mFocusText)) {
                    focusView = keyView;
                }
                keyView.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String s;
                        try {
                            s = ((TextView) v).getText().toString();
                        } catch (Exception e) {
                            s = null;
                        }
                        append(s);
                    }
                });
                if (i != 5)
                    continue;
                keyView.setOnKeyListener(new OnKeyListener() {
                    @Override
                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
                            RadioButton radioT9 = findViewById(R.id.keyboard_id_menu_t9);
                            if (radioT9.isChecked()) {
                                radioT9.requestFocus();
                                return true;
                            } else {
                                RadioButton radioFull = findViewById(R.id.keyboard_id_menu_full);
                                if (radioFull.isChecked()) {
                                    radioFull.requestFocus();
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                });
            }
        }

        if (null != focusView) {
            focusView.requestFocus();
        }
    }

    private final void initKeysMenu() {
        // 菜单
        ViewGroup menuLayout = (ViewGroup) LayoutInflater.from(getContext()).inflate(R.layout.module_keyboard_simple_menu, this, false);
        addView(menuLayout);
        if (null != menuLayout.getLayoutParams()) {
            ((LayoutParams) menuLayout.getLayoutParams()).topMargin = mMarginSpace;
            ((LayoutParams) menuLayout.getLayoutParams()).leftMargin = 0;
            ((LayoutParams) menuLayout.getLayoutParams()).rightMargin = 0;
            ((LayoutParams) menuLayout.getLayoutParams()).bottomMargin = 0;
        }
        for (int i = 0; i < 2; i++) {
            View childAt = menuLayout.getChildAt(i);
            if (null == childAt)
                continue;
            if (null != childAt.getLayoutParams()) {
                if (i == 0) {
                    ((LayoutParams) childAt.getLayoutParams()).leftMargin = 0;
                    ((LayoutParams) childAt.getLayoutParams()).rightMargin = mMarginMenu;
                } else {
                    ((LayoutParams) childAt.getLayoutParams()).leftMargin = mMarginMenu;
                    ((LayoutParams) childAt.getLayoutParams()).rightMargin = 0;
                }
            }
            childAt.setOnFocusChangeListener(new OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    // t9
                    if (hasFocus && R.id.keyboard_id_menu_t9 == v.getId()) {
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_t9)).setChecked(true);
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_full)).setChecked(false);
                        showT9();
                    }
                    // full
                    else if (hasFocus && R.id.keyboard_id_menu_full == v.getId()) {
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_t9)).setChecked(false);
                        ((RadioButton) findViewById(R.id.keyboard_id_menu_full)).setChecked(true);
                        showFull();
                    }
                }
            });
        }
    }

    private final void showT9() {
        int childCount = getChildCount();
        if (childCount <= 0)
            return;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (null == childAt)
                continue;
            int id = childAt.getId();
            childAt.setVisibility(id != R.id.keyboard_id_full_row ? View.VISIBLE : View.GONE);
        }
    }

    private final void showFull() {
        int childCount = getChildCount();
        if (childCount <= 0)
            return;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (null == childAt)
                continue;
            int id = childAt.getId();
            childAt.setVisibility(id != R.id.keyboard_id_t9_row ? View.VISIBLE : View.GONE);
        }
    }

    private void showFloatT9(String s, ViewGroup viewGroup) {

        if (null == s || s.length() <= 0)
            return;

        String trim = s.replace("\n", "").replace(" ", "").trim();
        char[] chars = trim.toCharArray();
        if (null == chars) {
            return;
        }

        int length = chars.length;
        if (length != 2 && length != 4 && length != 5)
            return;

        viewGroup.findViewById(R.id.module_keyboard_simple_t9_float).setVisibility(View.VISIBLE);
        // 01
        if (length == 2) {
            viewGroup.findViewById(R.id.module_keyboard_simple_t9_float_left).requestFocus();
        }
        // 7PQRS,9WXYZ
        else if (length == 5) {
            viewGroup.findViewById(R.id.module_keyboard_simple_t9_float_center).requestFocus();
        }
        // normal
        else {
            viewGroup.findViewById(R.id.module_keyboard_simple_t9_float_center).requestFocus();
        }
    }

    private boolean dispatchEvent(TextView textView, List<String> data, int direction) {
        try {
            View nextFocus = FocusFinder.getInstance().findNextFocus(KeyboardLinearLayout.this, textView, direction);
            CharSequence sequence = textView.getText();
            if (!data.contains(sequence)) {
                if (direction == View.FOCUS_DOWN && mKeyBottom.contains(data)) {
                    RadioButton t9Button = findViewById(R.id.keyboard_id_menu_t9);
                    if (t9Button.isChecked()) {
                        t9Button.requestFocus();
                        return true;
                    } else {
                        RadioButton fullButton = findViewById(R.id.keyboard_id_menu_full);
                        if (fullButton.isChecked()) {
                            fullButton.requestFocus();
                            return true;
                        } else {
                            throw new Exception("not find checked RadioButton");
                        }
                    }
                } else {
                    throw new Exception("not contains: " + sequence);
                }
            }
            if (null != nextFocus) {
                nextFocus.requestFocus();
                ViewGroup viewGroup = (ViewGroup) textView.getParent().getParent().getParent();
                viewGroup.findViewById(R.id.module_keyboard_simple_t9_float).setVisibility(View.GONE);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
