package tv.huan.keyboard.bean;

public final class T9Bean extends BaseBean {
    @Override
    public boolean isT9() {
        return true;
    }

    @Override
    public boolean isMenu() {
        return false;
    }
}
