package tv.huan.keyboard.impl;

import java.util.Arrays;
import java.util.List;

public interface KeyboardLinearLayoutImpl extends KeyboardImpl {

    String[][] mKeyFull = {{"A", "B", "C", "D", "E", "F"},
            {"G", "H", "I", "J", "K", "L"},
            {"M", "N", "O", "P", "Q", "R"},
            {"S", "T", "U", "V", "W", "X"},
            {"Y", "Z", "1", "2", "3", "4"},
            {"5", "6", "7", "8", "9", "0"}};

    String[][] mKeyT9 = {{"0 1", "2\nABC", "3\nDEF"},
            {"4\nGHI", "5\nJKL", "6\nMNO"},
            {"7\nPQRS", "8\nTUV", "9\nWXYZ"}};
    List<String> mKeyT9Left = Arrays.asList("1", "A", "D", "G", "J", "M", "P", "T", "W");
    List<String> mKeyT9Right = Arrays.asList("0", "C", "F", "I", "L", "O", "R", "V", "Y");
    List<String> mKeyT9Up = Arrays.asList("0", "1", "B", "E", "H", "K", "N", "Q", "U", "X");
    List<String> mKeyT9Down = Arrays.asList(
            "0", "1",
            "2", "A", "C",
            "3", "D", "F",
            "4", "G", "I",
            "5", "J", "L",
            "6", "M", "O",
            "S",
            "8", "T", "V",
            "Z");
    List<String> mKeyBottom = Arrays.asList(
            "5",
            "6",
            "7",
            "8",
            "9",
            "0",
            "S",
            "8", "T", "V",
            "Z");
}
