package tv.huan.keyboard.impl;

import androidx.annotation.DrawableRes;

import tv.huan.keyboard.bean.BaseBean;
import tv.huan.keyboard.bean.FullBean;
import tv.huan.keyboard.bean.MenuBean;
import tv.huan.keyboard.bean.T9Bean;

import java.util.LinkedList;

public interface KeyboardGridViewImpl extends KeyboardImpl {

    LinkedList<BaseBean> mDatas = new LinkedList<>();

    String[] mKeyFull = {"A", "B", "C", "D", "E", "F",
            "G", "H", "I", "J", "K", "L",
            "M", "N", "O", "P", "Q", "R",
            "S", "T", "U", "V", "W", "X",
            "Y", "Z", "1", "2", "3", "4",
            "5", "6", "7", "8", "9", "0",
            "全键盘", "T9键盘"};
    String[] mKeyT9 = {"0 1", "2\nABC", "3\nDEF",
            "4\nGHI", "5\nJKL", "6\nMNO",
            "7\nPQRS", "8\nTUV", "9\nWXYZ",
            "全键盘", "T9键盘"};
//    List<String> mKeyT9Left = Arrays.asList("0", "A", "D", "G", "J", "M", "P", "T", "W");

    default BaseBean getGridItem(int position) {
        try {
            return mDatas.get(position);
        } catch (Exception e) {
            return null;
        }
    }

    default int getGridCount() {
        return mDatas.size();
    }

    default int getGridSpan(int position) {
        try {
            BaseBean item = getGridItem(position);
            return item.isT9() ? 2 : item.isMenu() ? 3 : 1;
        } catch (Exception e) {
            throw e;
        }
    }

    default boolean showGridFull(@DrawableRes int fullBackgroundDrawableRes, @DrawableRes int menuBackgroundDrawableRes) {
        // 1
//        while (true) {
//            int count = getGridCount();
//            if (count <= 2)
//                break;
//            mDatas.removeFirst();
//        }
        mDatas.clear();

        // 2
        int length;
        int gridCount = getGridCount();
//        if (gridCount <= 0) {
        length = mKeyFull.length;
//        } else {
//            length = mKeyFull.length - 2;
//        }
        for (int i = 0; i < length; i++) {
            BaseBean bean;
            if (i < 36) {
                bean = new FullBean();
                bean.setBackgroundDrawableRes(fullBackgroundDrawableRes);
            } else {
                bean = new MenuBean();
                bean.setBackgroundDrawableRes(menuBackgroundDrawableRes);
            }
            bean.setName(mKeyFull[i]);
            mDatas.addLast(bean);
        }
        return gridCount <= 0;
    }

    default boolean showGridT9(@DrawableRes int t9BackgroundDrawableRes, @DrawableRes int menuBackgroundDrawableRes) {
        // 1
//        while (true) {
//            int count = getGridCount();
//            if (count <= 2)
//                break;
//            mDatas.removeFirst();
//        }
        mDatas.clear();

        // 2
        int length;
        int gridCount = getGridCount();
//        if (gridCount <= 0) {
        length = mKeyT9.length;
//        } else {
//            length = mKeyT9.length - 2;
//        }
        for (int i = 0; i < length; i++) {
            BaseBean bean;
            if (i < 9) {
                bean = new T9Bean();
                bean.setBackgroundDrawableRes(t9BackgroundDrawableRes);
            } else {
                bean = new MenuBean();
                bean.setBackgroundDrawableRes(menuBackgroundDrawableRes);
            }
            bean.setName(mKeyT9[i]);
            mDatas.addLast(bean);
        }
        return gridCount <= 0;
    }
}
