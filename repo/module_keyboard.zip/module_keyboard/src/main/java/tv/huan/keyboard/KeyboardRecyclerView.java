package tv.huan.keyboard;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.Keep;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import tv.huan.keyboard.bean.BaseBean;
import tv.huan.keyboard.impl.KeyboardGridViewImpl;

/**
 * 搜索键盘
 */
@Keep
public class KeyboardRecyclerView extends RecyclerView implements KeyboardGridViewImpl {

    @DrawableRes
    private int mBackgroundFull = 0;
    @DrawableRes
    private int mBackgroundT9 = 0;
    @DrawableRes
    private int mBackgroundMenu = 0;

    public KeyboardRecyclerView(@NonNull Context context) {
        super(context);
        init(context, null);
    }

    public KeyboardRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, null);
    }

    public KeyboardRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, null);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = (width / 6) * 8;
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setAdapter();
        showFull();
    }

    private final void init(Context context, AttributeSet attrs) {
        TypedArray attributes = null;
        try {
            attributes = context.obtainStyledAttributes(attrs, R.styleable.KeyboardGridView);
            mBackgroundMenu = attributes.getResourceId(R.styleable.KeyboardGridView_kgv_background_menu, 0);
            mBackgroundFull = attributes.getResourceId(R.styleable.KeyboardGridView_kgv_background_full, 0);
            mBackgroundT9 = attributes.getResourceId(R.styleable.KeyboardGridView_kgv_background_item_t9, 0);
        } catch (Exception e) {
        }
        if (null != attributes) {
            attributes.recycle();
        }
        setFocusable(true);
        setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        setHasFixedSize(true);
        setAnimation(null);
        setItemAnimator(null);
        setAnimationCacheEnabled(false);
        setNestedScrollingEnabled(false);
    }

    private void setAdapter() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 6) {
            @Override
            public boolean canScrollHorizontally() {
                return false;
            }

            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        gridLayoutManager.setOrientation(GridLayoutManager.VERTICAL);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                try {
                    return getGridSpan(position);
                } catch (Exception e) {
                    throw e;
                }
            }
        });
        setLayoutManager(gridLayoutManager);
        setAdapter(new Adapter() {
            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                @LayoutRes
                int resLayout;

                // menu
                if (viewType == 3) {
                    resLayout = R.layout.module_keyboard_grid_menu;
                }
                // t9
                else if (viewType == 2) {
                    resLayout = R.layout.module_keyboard_grid_t9;
                }
                // full
                else {
                    resLayout = R.layout.module_keyboard_grid_full;
                }

                View inflate = LayoutInflater.from(parent.getContext()).inflate(resLayout, null);
                // menu
                if (viewType == 3) {
                    inflate.setOnFocusChangeListener(new OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus) {
                                toggleKeyboard(v);
                            }
                        }
                    });
                }
                // t9
                else if (viewType == 2) {
                }
                // full
                else {
                }
                ViewHolder viewHolder = new ViewHolder(inflate) {
                };
                return viewHolder;
            }

            @Override
            public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

                BaseBean item = getGridItem(position);
                // menu
                if (holder.getItemViewType() == 3) {
                    ((RadioButton) holder.itemView).setText(item.getName());
                }
                // t9
                else if (holder.getItemViewType() == 2) {
//                    ((TextView) holder.itemView.findViewById(R.id.module_keyboard_grid_t9_preview)).setText(item.getName());
                }
                // full
                else {
                    ((TextView) holder.itemView).setText(item.getName());
                }
                holder.itemView.setBackgroundResource(item.getBackgroundDrawableRes());
            }

            @Override
            public int getItemViewType(int position) {
                return getGridSpan(position);
            }

            @Override
            public int getItemCount() {
                return getGridCount();
            }
        });
    }

    private void toggleKeyboard(View v) {
        String s;
        try {
            s = ((TextView) v).getText().toString();
        } catch (Exception e) {
            s = null;
        }
        if (null == s || s.length() <= 0)
            return;
        int gridCount = getGridCount();
        String sFull = getResources().getString(R.string.keyboard_full);
        String sT9 = getResources().getString(R.string.keyboard_t9);
        if (gridCount != 11 && sT9.equals(s)) {
            showT9();
        } else if (gridCount != 38 && sFull.equals(s)) {
            showFull();
        }
    }

    private void showFull() {
        boolean showGridFull = showGridFull(mBackgroundFull, mBackgroundMenu);
//        if (showGridFull) {
//            getAdapter().notifyItemRangeChanged(0, 38);
//        } else {
//        getAdapter().notifyItemRangeRemoved(0, 11);
        getAdapter().notifyItemRangeChanged(0, 38);
//        }
    }

    private void showT9() {
        boolean showGridT9 = showGridT9(mBackgroundT9, mBackgroundMenu);
//        if (showGridT9) {
//            getAdapter().notifyItemRangeChanged(0, 11);
//        } else {
//        getAdapter().notifyItemRangeRemoved(0, 38);
        getAdapter().notifyItemRangeChanged(0, 11);
//        }
    }

}
